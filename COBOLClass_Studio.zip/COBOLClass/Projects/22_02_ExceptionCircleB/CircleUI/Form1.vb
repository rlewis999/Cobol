Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents btnCalculate As System.Windows.Forms.Button
	Friend WithEvents btnExit As System.Windows.Forms.Button
	Friend WithEvents txtRadius As System.Windows.Forms.TextBox
	Friend WithEvents lblCircumference As System.Windows.Forms.Label
	Friend WithEvents lblArea As System.Windows.Forms.Label
	Friend WithEvents txtName As System.Windows.Forms.TextBox
	Friend WithEvents lblGreeting As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRadius = New System.Windows.Forms.TextBox()
        Me.lblCircumference = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblArea = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblGreeting = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(67, 207)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(176, 27)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Enter radius of a circle:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtRadius
        '
        Me.txtRadius.Location = New System.Drawing.Point(259, 212)
        Me.txtRadius.MaxLength = 4
        Me.txtRadius.Name = "txtRadius"
        Me.txtRadius.Size = New System.Drawing.Size(29, 22)
        Me.txtRadius.TabIndex = 2
        Me.txtRadius.Text = "0"
        Me.txtRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblCircumference
        '
        Me.lblCircumference.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCircumference.Location = New System.Drawing.Point(240, 286)
        Me.lblCircumference.Name = "lblCircumference"
        Me.lblCircumference.Size = New System.Drawing.Size(48, 28)
        Me.lblCircumference.TabIndex = 4
        Me.lblCircumference.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(86, 332)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(144, 28)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "The area is:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblArea
        '
        Me.lblArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblArea.Location = New System.Drawing.Point(230, 332)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(58, 28)
        Me.lblArea.TabIndex = 6
        Me.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(86, 286)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(144, 28)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "The circumference is:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(67, 378)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(96, 37)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(211, 378)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(96, 37)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(144, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 19)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Your name?"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(259, 166)
        Me.txtName.MaxLength = 20
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(96, 22)
        Me.txtName.TabIndex = 1
        '
        'lblGreeting
        '
        Me.lblGreeting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGreeting.Location = New System.Drawing.Point(86, 249)
        Me.lblGreeting.Name = "lblGreeting"
        Me.lblGreeting.Size = New System.Drawing.Size(260, 19)
        Me.lblGreeting.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(12, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(355, 58)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "This version of the circle example results in an exception if the name entry is l" & _
    "eft blank. The contents of the exception object are displayed."
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(400, 366)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblGreeting)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblArea)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblCircumference)
        Me.Controls.Add(Me.txtRadius)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label6)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Calculating Circumference and Area of a Circle"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

	Private Sub ButtonCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim CircleData As New CircleRecord
        Dim CircleWrapper As New CircleWrapper

		' Copy user input to object
		CircleData.Radius = txtRadius.Text
		If txtName.Text <> "" Then
			CircleData.UserName = txtName.Text
		End If

        Call CircleWrapper.Calculate(CircleData)

		' Access output from object
		lblGreeting.Text = CircleData.ReturnMessage
		lblCircumference.Text = CircleData.Circumference
		lblArea.Text = CircleData.CircleArea
		txtRadius.Text = CircleData.Radius
		txtName.Focus()

	End Sub

	Private Sub ButtonExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
		Application.Exit()
	End Sub


End Class
