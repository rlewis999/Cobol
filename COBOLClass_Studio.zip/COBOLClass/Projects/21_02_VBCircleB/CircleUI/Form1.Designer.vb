<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnCalculate = New System.Windows.Forms.Button
        Me.lblArea = New System.Windows.Forms.Label
        Me.lblCircumference = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.txtRadius = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(144, 224)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(77, 27)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "Exit"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(32, 224)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(77, 27)
        Me.btnCalculate.TabIndex = 16
        Me.btnCalculate.Text = "Calculate"
        '
        'lblArea
        '
        Me.lblArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblArea.Location = New System.Drawing.Point(152, 184)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(48, 20)
        Me.lblArea.TabIndex = 21
        Me.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCircumference
        '
        Me.lblCircumference.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCircumference.Location = New System.Drawing.Point(152, 154)
        Me.lblCircumference.Name = "lblCircumference"
        Me.lblCircumference.Size = New System.Drawing.Size(48, 20)
        Me.lblCircumference.TabIndex = 20
        Me.lblCircumference.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(46, 185)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(60, 13)
        Me.label6.TabIndex = 19
        Me.label6.Text = "The area is"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(44, 155)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(106, 13)
        Me.label5.TabIndex = 18
        Me.label5.Text = "The circumference is"
        '
        'txtRadius
        '
        Me.txtRadius.Location = New System.Drawing.Point(152, 119)
        Me.txtRadius.MaxLength = 2
        Me.txtRadius.Name = "txtRadius"
        Me.txtRadius.Size = New System.Drawing.Size(34, 20)
        Me.txtRadius.TabIndex = 13
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(46, 122)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(104, 13)
        Me.label3.TabIndex = 14
        Me.label3.Text = "Enter a radius value:"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(21, 19)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(214, 65)
        Me.label1.TabIndex = 10
        Me.label1.Text = resources.GetString("label1.Text")
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(264, 275)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblArea)
        Me.Controls.Add(Me.lblCircumference)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.txtRadius)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label1)
        Me.Name = "Form1"
        Me.Text = "Circle Calculation"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents btnExit As System.Windows.Forms.Button
    Private WithEvents btnCalculate As System.Windows.Forms.Button
    Private WithEvents lblArea As System.Windows.Forms.Label
    Private WithEvents lblCircumference As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents txtRadius As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label

End Class
