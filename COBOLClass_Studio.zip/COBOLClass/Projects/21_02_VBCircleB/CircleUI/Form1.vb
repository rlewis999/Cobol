Public Class Form1

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        CircleCalculations.Radius = txtRadius.Text
        CircleCalculations.Calculate()
        lblCircumference.Text = CircleCalculations.Circumference()
        lblArea.Text = CircleCalculations.CircleArea
        txtRadius.Focus()
        txtRadius.SelectAll()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
