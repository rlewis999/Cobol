Module Module1

    Sub Main()
		Dim dtmDateObject As System.DateTime
        Dim dateProcessingObject As New DateProcessing
        Call dateProcessingObject.SetDate()
        dtmDateObject = dateProcessingObject.dateObject
		Console.WriteLine(" ")
		Console.WriteLine("EXECUTING FROM VB ")
		Console.Write("   Full date-time: ")
		Console.WriteLine(dtmDateObject)
		Console.Write("Date with weekday: ")
		Console.WriteLine(dtmDateObject.ToLongDateString)
		Console.Write("        Date only: ")
		Console.WriteLine(dtmDateObject.ToShortDateString)
		Console.WriteLine(" ")
		Console.Write("Press Enter to terminate ")
		Console.ReadLine()
	End Sub

End Module
