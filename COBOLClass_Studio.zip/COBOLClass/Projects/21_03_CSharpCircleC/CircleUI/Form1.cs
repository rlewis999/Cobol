﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CircleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var circleClassObject = new CircleCalculations();            

            circleClassObject.UserName = txtName.Text;
            circleClassObject.Radius = Decimal.Parse(txtRadius.Text);
            circleClassObject.Calculate();
            lblGreeting.Text = circleClassObject.ReturnMessage;
            lblCircumference.Text = circleClassObject.Circumference.ToString();
            lblArea.Text = circleClassObject.CircleArea.ToString();
            txtRadius.Focus();
            txtRadius.SelectAll();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
