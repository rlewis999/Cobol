Module Module1

	Sub Main()
		Dim Radius As Int16
		Dim RadiusString As String
		Dim Area As Single
		Dim Circumference As Single

		Console.WriteLine("        CIRCLE CALCULATION")
		Console.WriteLine("This program accepts an input radius &")
		Console.WriteLine("computes the circumference and area.")
		Console.WriteLine("To terminate execution,")
		Console.WriteLine("press Enter without typing a value.")
		Console.WriteLine(" ")

		Console.Write("Radius? ")
		RadiusString = Console.ReadLine()
		Do
			Radius = RadiusString
			Circumference = 6.28 * Radius
			Area = 3.14 * Radius * Radius
			Console.Write("Circumference = ")
			Console.WriteLine(Circumference)
			Console.Write("         Area = ")
			Console.WriteLine(Area)
			Console.WriteLine()
			Console.Write("Radius? ")
			RadiusString = Console.ReadLine()
		Loop While RadiusString <> ""
	End Sub

End Module
