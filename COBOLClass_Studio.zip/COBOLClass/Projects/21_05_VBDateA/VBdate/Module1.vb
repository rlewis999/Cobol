Module Module1

    Sub Main()
		Dim intMonth, intDay, intYear As Int32
		Dim strMonth, strDay, strYear As String
        Dim strAnother As String
        Dim dateProcessingObject As New DateProcessing

		Console.WriteLine("        DATE PROCESSING")
		Console.WriteLine("This program demonstrates date handling.")
		Console.WriteLine("Enter a date carefully as there is no error checking.")
		Console.WriteLine(" ")

		Do
			Console.WriteLine("ACCEPTING DATA FROM VB")
			Console.Write("      Month: ")
			strMonth = Console.ReadLine()
			Console.Write("        Day: ")
			strDay = Console.ReadLine()
			Console.Write("Year (yyyy): ")
			strYear = Console.ReadLine()

			'Write date string to date object
			strMonth = strMonth.PadLeft(2, "0")
			strDay = strDay.PadLeft(2, "0")
            dateProcessingObject.FullDate = String.Concat(strYear, strMonth, strDay)

			'Call Cobol class to display and update the date
            dateProcessingObject.ReceiveDate()

            intYear = Integer.Parse(dateProcessingObject.FullDate.Substring(0, 4))
            intMonth = Integer.Parse(dateProcessingObject.FullDate.Substring(4, 2))
            intDay = Integer.Parse(dateProcessingObject.FullDate.Substring(6, 2))
			Dim dtmVBdate As New DateTime(intYear, intMonth, intDay)
			Console.WriteLine(" ")
			Console.WriteLine("EXECUTING FROM VB ")
			Console.Write("Full date-time:    ")
			Console.WriteLine(dtmVBdate)
			Console.Write("Date with weekday: ")
			Console.WriteLine(dtmVBdate.ToLongDateString)
			Console.Write("Date only:         ")
			Console.WriteLine(dtmVBdate.ToShortDateString)

			Console.WriteLine(" ")
			Console.Write("Try another? <y/n> ")
			strAnother = Console.ReadLine()
		Loop Until strAnother = "n" Or strAnother = "N"


    End Sub

End Module
