﻿//*******************************************************************************************************
//
// * Copyright (C) Micro Focus 2010-2012.
// * All rights reserved.
// *
// *  This sample code is supplied for demonstration purposes only on an "as is" basis and "is for use at
// *  your own risk".
//
//*******************************************************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
