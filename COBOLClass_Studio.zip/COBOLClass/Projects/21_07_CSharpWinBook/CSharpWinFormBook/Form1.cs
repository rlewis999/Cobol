﻿//*******************************************************************************************************
//
// Copyright (C) Micro Focus 2010-2012.
// All rights reserved.
//
//  This sample code is supplied for demonstration purposes only on an "as is" basis and "is for use at
//  your own risk".
//
//*******************************************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        BookLegacy _book;
        Details _details;
        FileStatus _status;

        const string readRecord   = "1";
        const string addRecord    = "2";
        const string deleteRecord = "3";
        const string nextRecord   = "4";
        const string allRecords   = "5";

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This method raises an event that calls the Read method in LegacyBook, then populates and displays the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonRead_Click(object sender, EventArgs e)
        {
            Details.Stockno = textBoxStockNo.Text;

            try
            {
                Book.BookLegacy(readRecord, Details, Status);
                PopulateForm(Details);
            }
            catch (Exception exception)
            {
                DisplayException(exception);
            }
        }

        /// <summary>
        /// This method calls the LegacyBook with the Add parameter to add information from the form in the current
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Details.Stockno = textBoxStockNo.Text;
                Details.Title = textBoxTitle.Text;
                Details.Author = textBoxAuthor.Text;
                Details.Type = textBoxType.Text;

                if (textBoxPrice.Text.Length == 0)
                    textBoxPrice.Text = "0";
                Details.Retail = System.Convert.ToDecimal(textBoxPrice.Text);

                if (textBoxOnHand.Text.Length == 0)
                    textBoxOnHand.Text = "0";
                Details.Onhand = System.Convert.ToUInt32(textBoxOnHand.Text);

                if (textBoxSold.Text.Length == 0)
                    textBoxSold.Text = "0";
                Details.Sold = System.Convert.ToUInt32(textBoxSold.Text);

                Book.BookLegacy(addRecord, Details, Status);

                PopulateForm(Details);
            }
            catch (System.FormatException formatException)
            {
                DisplayException(formatException);
            }
            catch (SystemException exception)
            {
                DisplayException(exception);
            }
        }

        /// <summary>
        /// This method calls the LegacyBook with Delete parameter to delete information from the current working file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            Details.Stockno = textBoxStockNo.Text;

            try
            {
                Book.BookLegacy(deleteRecord, Details, Status);
            }
            catch (Exception exception)
            {
                DisplayException(exception);
            }
        }

        /// <summary>
        /// This method calls the BookLegacy with the Next parameter to move to the next record by given "stock number"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonNext_Click(object sender, EventArgs e)
        {
            Details.Stockno = textBoxStockNo.Text;
            try
            {
                Book.BookLegacy(nextRecord, Details, Status);
                PopulateForm(Details);
            }
            catch (SystemException exception)
            {
                DisplayException(exception);
            }
        }

        /// <summary>
        /// This method closes the application.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// PopulateForm
        /// Moves the book data retrieved from the legacy program to the fields on
        /// the winform.
        /// </summary>
        /// <param name="details"></param>
        private void PopulateForm(Details details)
        {
            if (details != null)
            {
                textBoxStockNo.Text = details.Stockno;
                textBoxTitle.Text = details.Title;
                textBoxAuthor.Text = details.Author;
                textBoxType.Text = details.Type;
                textBoxPrice.Text = System.Convert.ToString(details.Retail);
                textBoxOnHand.Text = System.Convert.ToString(details.Onhand);
                textBoxSold.Text = System.Convert.ToString(details.Sold);
                textBoxStockValue.Text = System.Convert.ToString(StockValue);
            }
            else
            {
                textBoxStockNo.Text = "****";
                textBoxTitle.Text   = "*******************";
                textBoxAuthor.Text  = "*******************";
                textBoxType.Text    = "****";
                textBoxPrice.Text   = "****";
                textBoxOnHand.Text  = "****";
                textBoxSold.Text    = "****";
            }
        }

        private void DisplayException(Exception exception)
        {
            PopulateForm(null);
        }

        public BookLegacy Book
        {
            get 
            {
                if (_book == null)
                    _book = new BookLegacy();
                return _book; 
            }
        }

        public Details Details
        {
            get 
            {
                if (_details == null)
                    _details = new Details();
                return _details; 
            }
        }

        public FileStatus Status
        {
            get 
            {
                if (_status == null)
                    _status = new FileStatus();
                return _status; 
            }
        }

        public decimal StockValue
        {
            get
            {
                return (Details.Retail * Details.Onhand);
            }
        }
    }
}
