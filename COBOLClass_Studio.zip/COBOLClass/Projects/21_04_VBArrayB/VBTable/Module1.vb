Module Module1

    Sub Main()
		Dim NameArray(5) As String
		Dim SalesArray(5) As Decimal
		Dim i As Integer
        Dim QueryString As String
        Dim tableAccessObject As New TableAccess
        tableAccessObject.FillArray()
        NameArray = tableAccessObject.stringArray
        SalesArray = tableAccessObject.decimalArray
		For i = 0 To 4
			Console.Write(NameArray(i))
			Console.Write(" ")
			Console.WriteLine(SalesArray(i))
		Next
		Console.WriteLine(" ")
		Console.WriteLine("Press the Enter key to terminate")
		QueryString = Console.Read()

    End Sub

End Module
