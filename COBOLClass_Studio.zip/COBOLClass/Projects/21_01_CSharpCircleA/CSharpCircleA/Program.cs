﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Circle
{
    class Program
    {
        static void Main(string[] args)
        {
            Int16 radius;
            string radiusString;
            Single area; 
            Single circumference;

            Console.WriteLine("        CIRCLE CALCULATION");
            Console.WriteLine("This program accepts an input radius &");
            Console.WriteLine("computes the circumference and area.");
            Console.WriteLine("To terminate execution,");
            Console.WriteLine("press Enter without typing a value.");
            Console.WriteLine(" ");

            Console.Write("Radius? ");
            radiusString = Console.ReadLine();

            do
            {
                radius = Convert.ToInt16(radiusString);
                circumference = (Single)(6.28 * radius);
                area = (Single)(3.14 * radius * radius);
                Console.Write("Circumference = ");
                Console.WriteLine(circumference);
                Console.Write("         Area = ");
                Console.WriteLine(area);
                Console.WriteLine();
                Console.Write("Radius? ");
                radiusString = Console.ReadLine();
            } while (radiusString != "");
        }
    }
}
