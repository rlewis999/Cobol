Public Class Form1
	Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

	Public Sub New()
		MyBase.New()

		'This call is required by the Windows Form Designer.
		InitializeComponent()

		'Add any initialization after the InitializeComponent() call

	End Sub

	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If Not (components Is Nothing) Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents btnCalculate As System.Windows.Forms.Button
	Friend WithEvents btnExit As System.Windows.Forms.Button
	Friend WithEvents txtRadius As System.Windows.Forms.TextBox
	Friend WithEvents lblCircumference As System.Windows.Forms.Label
	Friend WithEvents lblArea As System.Windows.Forms.Label
	Friend WithEvents txtName As System.Windows.Forms.TextBox
	Friend WithEvents lblGreeting As System.Windows.Forms.Label
	Friend WithEvents lstException As System.Windows.Forms.ListBox
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRadius = New System.Windows.Forms.TextBox()
        Me.lblCircumference = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblArea = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblGreeting = New System.Windows.Forms.Label()
        Me.lstException = New System.Windows.Forms.ListBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(505, 99)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = resources.GetString("Label1.Text")
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(47, 231)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 26)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Enter radius of a circle:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtRadius
        '
        Me.txtRadius.Location = New System.Drawing.Point(229, 231)
        Me.txtRadius.MaxLength = 4
        Me.txtRadius.Name = "txtRadius"
        Me.txtRadius.Size = New System.Drawing.Size(28, 22)
        Me.txtRadius.TabIndex = 2
        Me.txtRadius.Text = "0"
        Me.txtRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblCircumference
        '
        Me.lblCircumference.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCircumference.Location = New System.Drawing.Point(210, 305)
        Me.lblCircumference.Name = "lblCircumference"
        Me.lblCircumference.Size = New System.Drawing.Size(47, 27)
        Me.lblCircumference.TabIndex = 4
        Me.lblCircumference.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(56, 351)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(143, 27)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "The area is:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblArea
        '
        Me.lblArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblArea.Location = New System.Drawing.Point(200, 351)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(57, 27)
        Me.lblArea.TabIndex = 6
        Me.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(56, 305)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(143, 27)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "The circumference is:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(37, 397)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(95, 37)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(181, 397)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(95, 37)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(114, 185)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 18)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Your name?"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(229, 185)
        Me.txtName.MaxLength = 20
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(95, 22)
        Me.txtName.TabIndex = 1
        '
        'lblGreeting
        '
        Me.lblGreeting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGreeting.Location = New System.Drawing.Point(56, 268)
        Me.lblGreeting.Name = "lblGreeting"
        Me.lblGreeting.Size = New System.Drawing.Size(258, 18)
        Me.lblGreeting.TabIndex = 11
        '
        'lstException
        '
        Me.lstException.ItemHeight = 16
        Me.lstException.Items.AddRange(New Object() {"Subscript", "Other"})
        Me.lstException.Location = New System.Drawing.Point(47, 111)
        Me.lstException.Name = "lstException"
        Me.lstException.Size = New System.Drawing.Size(73, 36)
        Me.lstException.TabIndex = 24
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(133, 129)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(384, 19)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Other:       Creates invalid subprogram call.  No recovery."
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(133, 108)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(407, 18)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Subscript:  Creates an out-of-range subscript.  No recovery."
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(523, 448)
        Me.Controls.Add(Me.lstException)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblGreeting)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtRadius)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblArea)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblCircumference)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label6)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Calculating Circumference and Area of a Circle"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

	Private Sub ButtonCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim CircleData As New CircleRecord
        Dim CircleWrapper As New CircleWrapper

		'  Copy user input to object
		CircleData.Radius = txtRadius.Text
		CircleData.UserName = txtName.Text
		CircleData.ExceptionOption = lstException.Text

        Call CircleWrapper.Calculate(CircleData)

        ' Access output from object
        lblGreeting.Text = CircleData.UserName
        lblCircumference.Text = CircleData.Circumference
        lblArea.Text = CircleData.CircleArea
        txtName.Focus()

	End Sub

	Private Sub ButtonExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
		Application.Exit()
	End Sub


End Class
