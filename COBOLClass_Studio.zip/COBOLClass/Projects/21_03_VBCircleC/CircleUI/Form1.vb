Public Class Form1

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Dim circleClassObject As New CircleCalculations

        circleClassObject.UserName = txtName.Text
        circleClassObject.Radius = txtRadius.Text
        circleClassObject.Calculate()
        lblGreeting.Text = circleClassObject.ReturnMessage
        lblCircumference.Text = circleClassObject.Circumference
        lblArea.Text = circleClassObject.CircleArea
        txtRadius.Focus()
        txtRadius.SelectAll()

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Application.Exit()

    End Sub
End Class
